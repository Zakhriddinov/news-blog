function kubik(n) {
  let a = Math.pow(n, 2);
  let list = [];
  for (let i = 1; i <= a; i++) {
    list.push(i);
    if (list.length >= n) {
      console.log(list + "\n");
      list = [];
    }
  }
}
kubik(5);
